If you have missing water on one spot then you need to find on your server gta5 meta files and edit like on picture1

if water dont work that mean that your server dont read gta5.meta file from our river map


THIS PART NEED TO BE INSIDE other gta5.meta files



	  <filename>resources:/cfx-nteam-river/heightmap.dat</filename>
	  <fileType>WORLD_HEIGHTMAP_FILE</fileType>
	
	


